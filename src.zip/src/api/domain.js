// 配置全局接口域名
const domain = 'http://eggs.apexgame.cn/';
export default {
    url: domain
}