// 配置全局变量
const domain = 'https://server.apexgame.cn/';
const urlPath = '/EggsWebService.asmx';
export default {
    domian: domain,
    urlPath: urlPath
}