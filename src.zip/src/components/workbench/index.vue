<template>
  <div id="myinbox">
    工作台
  </div>
</template>
<script>
export default {

  data() {
    return {
    };
  }
};
</script>
<style lang='less'>
#myinbox {
  width: 100%;
  height: 100%;
}
</style>

